import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Pause, Play, AlertTriangle, Wrench } from "lucide-react";
import { machines, productionData } from "@/data/mockData";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, BarChart, Bar } from "recharts";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function MachineDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const machine = machines.find(m => m.id === id);
  const [pauseDialog, setPauseDialog] = useState(false);

  if (!machine) return <div className="text-center py-20 text-muted-foreground">Machine not found</div>;

  const progress = machine.targetParts > 0 ? Math.round((machine.partsCompleted / machine.targetParts) * 100) : 0;

  const handlePause = () => {
    toast.success(`${machine.name} paused`);
    setPauseDialog(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate('/machines')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold">{machine.name}</h1>
          <p className="text-sm text-muted-foreground">{machine.id} · {machine.type} · {machine.location}</p>
        </div>
        <StatusBadge status={machine.status} type="machine" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Machine Info */}
        <div className="card-industrial space-y-3">
          <h3 className="text-sm font-semibold font-mono-display text-muted-foreground">Machine Info</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Machine ID</span><span className="font-mono-display">{machine.id}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Type</span><span>{machine.type}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Location</span><span>{machine.location}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Last Maintenance</span><span className="font-mono-display">{machine.lastMaintenance}</span></div>
          </div>
        </div>

        {/* Current Job */}
        <div className="card-industrial space-y-3">
          <h3 className="text-sm font-semibold font-mono-display text-muted-foreground">Current Job</h3>
          {machine.currentJobId ? (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Job ID</span><span className="font-mono-display">{machine.currentJobId}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Part</span><span>{machine.currentJobName}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Target</span><span className="font-mono-display">{machine.targetParts}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Completed</span><span className="font-mono-display">{machine.partsCompleted}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Cycle Time</span><span className="font-mono-display">{machine.cycleTime}s</span></div>
              <div className="space-y-1 pt-1">
                <div className="flex justify-between text-xs text-muted-foreground"><span>Progress</span><span>{progress}%</span></div>
                <Progress value={progress} className="h-2" />
              </div>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No active job</p>
          )}
        </div>

        {/* Uptime */}
        <div className="card-industrial space-y-3">
          <h3 className="text-sm font-semibold font-mono-display text-muted-foreground">Performance</h3>
          <div className="flex flex-col items-center justify-center py-4">
            <div className="relative w-28 h-28">
              <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(220 15% 20%)" strokeWidth="8" />
                <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(199 89% 48%)" strokeWidth="8"
                  strokeDasharray={`${machine.uptime * 2.64} ${264 - machine.uptime * 2.64}`} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-bold font-mono-display">{machine.uptime}%</span>
                <span className="text-[10px] text-muted-foreground">Uptime</span>
              </div>
            </div>
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Operator</span>
            <span className="text-foreground">{machine.operatorName || '—'}</span>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card-industrial">
          <h3 className="text-sm font-semibold font-mono-display mb-4">Cycle Time Trend</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={productionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 20%)" />
                <XAxis dataKey="hour" tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <YAxis tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <Tooltip contentStyle={{ background: 'hsl(220 18% 13%)', border: '1px solid hsl(220 15% 20%)', borderRadius: 8, fontSize: 12 }} />
                <Area type="monotone" dataKey="production" stroke="hsl(199 89% 48%)" fill="hsl(199 89% 48% / 0.1)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card-industrial">
          <h3 className="text-sm font-semibold font-mono-display mb-4">Production Per Hour</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={productionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 20%)" />
                <XAxis dataKey="hour" tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <YAxis tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <Tooltip contentStyle={{ background: 'hsl(220 18% 13%)', border: '1px solid hsl(220 15% 20%)', borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="production" fill="hsl(199 89% 48%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3">
        <Button size="lg" variant="secondary" onClick={() => setPauseDialog(true)}>
          <Pause className="h-4 w-4 mr-2" /> Pause Machine
        </Button>
        <Button size="lg" variant="default">
          <Play className="h-4 w-4 mr-2" /> Resume
        </Button>
        <Button size="lg" variant="destructive">
          <AlertTriangle className="h-4 w-4 mr-2" /> Report Breakdown
        </Button>
      </div>

      {/* Pause Dialog */}
      <Dialog open={pauseDialog} onOpenChange={setPauseDialog}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-mono-display">Reason for Pause</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Select Reason</Label>
            <Select>
              <SelectTrigger><SelectValue placeholder="Choose reason" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="tool-change">Tool Change</SelectItem>
                <SelectItem value="material-shortage">Material Shortage</SelectItem>
                <SelectItem value="maintenance">Maintenance</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setPauseDialog(false)}>Cancel</Button>
            <Button onClick={handlePause}>Confirm Pause</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
