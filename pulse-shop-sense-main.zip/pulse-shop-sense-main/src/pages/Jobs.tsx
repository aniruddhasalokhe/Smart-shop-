import { Briefcase, Play, Square, Eye } from "lucide-react";
import { jobs } from "@/data/mockData";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function Jobs() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Job Management</h1>
        <p className="text-sm text-muted-foreground">{jobs.length} jobs total · {jobs.filter(j => j.status === 'in-progress').length} active</p>
      </div>

      <div className="card-industrial overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground">
              <th className="pb-3 font-medium">Job ID</th>
              <th className="pb-3 font-medium">Part Name</th>
              <th className="pb-3 font-medium">Machine</th>
              <th className="pb-3 font-medium">Operator</th>
              <th className="pb-3 font-medium">Target</th>
              <th className="pb-3 font-medium">Produced</th>
              <th className="pb-3 font-medium">Completion</th>
              <th className="pb-3 font-medium">Status</th>
              <th className="pb-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {jobs.map(job => {
              const pct = Math.round((job.producedQuantity / job.targetQuantity) * 100);
              return (
                <tr key={job.id} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                  <td className="py-3 font-mono-display font-medium">{job.id}</td>
                  <td className="py-3">{job.partName}</td>
                  <td className="py-3 font-mono-display text-xs">{job.machineId}</td>
                  <td className="py-3">{job.operatorName}</td>
                  <td className="py-3 font-mono-display">{job.targetQuantity}</td>
                  <td className="py-3 font-mono-display">{job.producedQuantity}</td>
                  <td className="py-3">
                    <div className="flex items-center gap-2 min-w-[100px]">
                      <Progress value={pct} className="h-2 flex-1" />
                      <span className="font-mono-display text-xs">{pct}%</span>
                    </div>
                  </td>
                  <td className="py-3"><StatusBadge status={job.status} type="job" size="sm" /></td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      {job.status === 'pending' && (
                        <Button size="sm" variant="default" onClick={() => toast.success(`Started ${job.id}`)}>
                          <Play className="h-3 w-3 mr-1" /> Start
                        </Button>
                      )}
                      {job.status === 'in-progress' && (
                        <Button size="sm" variant="destructive" onClick={() => toast.info(`Stopped ${job.id}`)}>
                          <Square className="h-3 w-3 mr-1" /> Stop
                        </Button>
                      )}
                      <Button size="sm" variant="ghost">
                        <Eye className="h-3 w-3" />
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}
