import { Bell, AlertTriangle, AlertCircle, Info } from "lucide-react";
import { notifications } from "@/data/mockData";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

const iconMap = {
  error: AlertCircle,
  warning: AlertTriangle,
  info: Info,
};

const colorMap = {
  error: 'text-status-down bg-status-down/10 border-status-down/20',
  warning: 'text-status-idle bg-status-idle/10 border-status-idle/20',
  info: 'text-primary bg-primary/10 border-primary/20',
};

export default function Notifications() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Notifications</h1>
        <p className="text-sm text-muted-foreground">{notifications.filter(n => !n.read).length} unread alerts</p>
      </div>

      <div className="space-y-3">
        {notifications.map(n => {
          const Icon = iconMap[n.type];
          return (
            <div
              key={n.id}
              className={cn("card-industrial flex items-start gap-3 border", colorMap[n.type], !n.read && 'border-l-4')}
            >
              <Icon className="h-5 w-5 mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm">{n.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{n.timestamp}</p>
              </div>
              {!n.read && <span className="w-2 h-2 rounded-full bg-primary shrink-0 mt-2" />}
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}
