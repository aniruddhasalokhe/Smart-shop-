import { useNavigate } from "react-router-dom";
import { Monitor, AlertTriangle, Eye, Wrench } from "lucide-react";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { machines } from "@/data/mockData";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export default function Machines() {
  const navigate = useNavigate();
  const [issueDialog, setIssueDialog] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState("");

  const handleReportIssue = (machineId: string) => {
    setSelectedMachine(machineId);
    setIssueDialog(true);
  };

  const submitIssue = () => {
    toast.success(`Issue reported for ${selectedMachine}`);
    setIssueDialog(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Machine Monitoring</h1>
          <p className="text-sm text-muted-foreground">{machines.length} machines on shop floor</p>
        </div>
        <div className="flex gap-2 text-xs font-mono-display text-muted-foreground">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-status-running" /> {machines.filter(m => m.status === 'running').length} Running</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-status-idle" /> {machines.filter(m => m.status === 'idle').length} Idle</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-status-down" /> {machines.filter(m => m.status === 'breakdown').length} Down</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {machines.map(m => {
          const progress = m.targetParts > 0 ? Math.round((m.partsCompleted / m.targetParts) * 100) : 0;
          return (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`card-industrial space-y-3 ${m.status === 'breakdown' ? 'glow-down border-status-down/30' : m.status === 'running' ? 'glow-running border-status-running/20' : ''}`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-mono-display font-bold text-base">{m.name}</p>
                  <p className="text-xs text-muted-foreground">{m.id} · {m.type}</p>
                </div>
                <StatusBadge status={m.status} type="machine" size="sm" />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-secondary/50 rounded p-2">
                  <span className="text-muted-foreground">Job</span>
                  <p className="font-medium truncate">{m.currentJobName || '—'}</p>
                </div>
                <div className="bg-secondary/50 rounded p-2">
                  <span className="text-muted-foreground">Operator</span>
                  <p className="font-medium truncate">{m.operatorName || '—'}</p>
                </div>
                <div className="bg-secondary/50 rounded p-2">
                  <span className="text-muted-foreground">Cycle Time</span>
                  <p className="font-mono-display font-medium">{m.cycleTime > 0 ? `${m.cycleTime}s` : '—'}</p>
                </div>
                <div className="bg-secondary/50 rounded p-2">
                  <span className="text-muted-foreground">Parts</span>
                  <p className="font-mono-display font-medium">{m.partsCompleted}/{m.targetParts}</p>
                </div>
              </div>

              {m.targetParts > 0 && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Progress</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              )}

              <div className="flex gap-2">
                <Button size="sm" variant="secondary" className="flex-1" onClick={() => navigate(`/machines/${m.id}`)}>
                  <Eye className="h-3.5 w-3.5 mr-1" /> View Details
                </Button>
                <Button size="sm" variant="destructive" className="flex-1" onClick={() => handleReportIssue(m.id)}>
                  <AlertTriangle className="h-3.5 w-3.5 mr-1" /> Report Issue
                </Button>
              </div>
            </motion.div>
          );
        })}
      </div>

      <Dialog open={issueDialog} onOpenChange={setIssueDialog}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-mono-display">Report Issue — {selectedMachine}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Issue Type</Label>
              <Select>
                <SelectTrigger><SelectValue placeholder="Select issue type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="breakdown">Breakdown</SelectItem>
                  <SelectItem value="tool-failure">Tool Failure</SelectItem>
                  <SelectItem value="material-issue">Material Issue</SelectItem>
                  <SelectItem value="quality-issue">Quality Issue</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea placeholder="Describe the issue..." className="min-h-[100px]" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setIssueDialog(false)}>Cancel</Button>
            <Button onClick={submitIssue}>Submit Issue</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
