import { Users } from "lucide-react";
import { operators, machines } from "@/data/mockData";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";

export default function Operators() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Operator Management</h1>
        <p className="text-sm text-muted-foreground">{operators.length} operators registered</p>
      </div>

      <div className="card-industrial overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground">
              <th className="pb-3 font-medium">Operator ID</th>
              <th className="pb-3 font-medium">Name</th>
              <th className="pb-3 font-medium">Machine</th>
              <th className="pb-3 font-medium">Shift</th>
              <th className="pb-3 font-medium">Status</th>
              <th className="pb-3 font-medium">Efficiency</th>
              <th className="pb-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {operators.map(op => (
              <tr key={op.id} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                <td className="py-3 font-mono-display">{op.id}</td>
                <td className="py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">{op.avatar}</div>
                    {op.name}
                  </div>
                </td>
                <td className="py-3 font-mono-display">{op.machineAssigned || '—'}</td>
                <td className="py-3">{op.shift}</td>
                <td className="py-3"><StatusBadge status={op.attendanceStatus} type="operator" size="sm" /></td>
                <td className="py-3">
                  <div className="flex items-center gap-2 min-w-[120px]">
                    <Progress value={op.efficiency} className="h-2 flex-1" />
                    <span className="font-mono-display text-xs">{op.efficiency}%</span>
                  </div>
                </td>
                <td className="py-3">
                  <div className="flex gap-1">
                    <Button size="sm" variant="secondary">Assign Machine</Button>
                    <Button size="sm" variant="ghost">Performance</Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}
