import { useNavigate } from "react-router-dom";
import { Monitor, Zap, Package, Clock, TrendingUp, Users } from "lucide-react";
import { KpiCard } from "@/components/KpiCard";
import { StatusBadge } from "@/components/StatusBadge";
import { machines, operators, jobs, productionData } from "@/data/mockData";
import { motion } from "framer-motion";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export default function Dashboard() {
  const navigate = useNavigate();

  const running = machines.filter(m => m.status === 'running').length;
  const idle = machines.filter(m => m.status === 'idle').length;
  const down = machines.filter(m => m.status === 'breakdown').length;
  const totalParts = machines.reduce((s, m) => s + m.partsCompleted, 0);
  const completedJobs = jobs.filter(j => j.status === 'completed').length;
  const avgCycle = Math.round(machines.filter(m => m.cycleTime > 0).reduce((s, m) => s + m.cycleTime, 0) / machines.filter(m => m.cycleTime > 0).length);
  const avgEfficiency = Math.round(operators.reduce((s, o) => s + o.efficiency, 0) / operators.length);

  const container = { hidden: {}, show: { transition: { staggerChildren: 0.05 } } };
  const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } };

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Shop floor overview — {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
      </div>

      {/* Machine Overview */}
      <motion.div variants={item} className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KpiCard title="Total Machines" value={machines.length} icon={Monitor} accentColor="primary" />
        <KpiCard title="Running" value={running} icon={Zap} accentColor="running" trend="up" trendValue="2 vs yesterday" />
        <KpiCard title="Idle" value={idle} icon={Clock} accentColor="idle" />
        <KpiCard title="Down" value={down} icon={Monitor} accentColor="down" />
      </motion.div>

      {/* Production KPIs */}
      <motion.div variants={item} className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KpiCard title="Jobs Completed" value={completedJobs} subtitle="today" icon={Package} />
        <KpiCard title="Parts Produced" value={totalParts} icon={Package} trend="up" trendValue="+12% vs avg" />
        <KpiCard title="Avg Cycle Time" value={`${avgCycle}s`} icon={Clock} />
        <KpiCard title="Efficiency" value={`${avgEfficiency}%`} icon={TrendingUp} trend="up" trendValue="+3.2%" />
      </motion.div>

      {/* Production Chart + Operator Attendance side by side */}
      <motion.div variants={item} className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 card-industrial">
          <h3 className="text-sm font-semibold font-mono-display mb-4">Production Today (parts/hour)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={productionData}>
                <defs>
                  <linearGradient id="prodGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(199 89% 48%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(199 89% 48%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 20%)" />
                <XAxis dataKey="hour" tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <YAxis tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <Tooltip contentStyle={{ background: 'hsl(220 18% 13%)', border: '1px solid hsl(220 15% 20%)', borderRadius: 8, fontSize: 12 }} />
                <Area type="monotone" dataKey="target" stroke="hsl(215 15% 35%)" strokeDasharray="5 5" fill="transparent" />
                <Area type="monotone" dataKey="production" stroke="hsl(199 89% 48%)" fill="url(#prodGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card-industrial">
          <div className="flex items-center gap-2 mb-4">
            <Users className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-semibold font-mono-display">Operator Attendance</h3>
          </div>
          <div className="space-y-3">
            {operators.slice(0, 5).map(op => (
              <div key={op.id} className="flex items-center justify-between p-2 rounded-md bg-secondary/50">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">
                    {op.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{op.name}</p>
                    <p className="text-xs text-muted-foreground">{op.checkInTime || '—'}</p>
                  </div>
                </div>
                <StatusBadge status={op.attendanceStatus} type="operator" size="sm" />
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Live Machine Status Board */}
      <motion.div variants={item} className="card-industrial">
        <h3 className="text-sm font-semibold font-mono-display mb-4">Live Machine Status Board</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-muted-foreground">
                <th className="pb-3 font-medium">Machine ID</th>
                <th className="pb-3 font-medium">Operator</th>
                <th className="pb-3 font-medium">Current Job</th>
                <th className="pb-3 font-medium">Cycle Time</th>
                <th className="pb-3 font-medium">Parts</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {machines.map(m => (
                <tr
                  key={m.id}
                  className="border-b border-border/50 cursor-pointer hover:bg-secondary/30 transition-colors"
                  onClick={() => navigate(`/machines/${m.id}`)}
                >
                  <td className="py-3 font-mono-display font-medium">{m.id}</td>
                  <td className="py-3">{m.operatorName || '—'}</td>
                  <td className="py-3">{m.currentJobName || '—'}</td>
                  <td className="py-3 font-mono-display">{m.cycleTime > 0 ? `${m.cycleTime}s` : '—'}</td>
                  <td className="py-3 font-mono-display">{m.partsCompleted > 0 ? m.partsCompleted : '—'}</td>
                  <td className="py-3"><StatusBadge status={m.status} type="machine" size="sm" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  );
}
