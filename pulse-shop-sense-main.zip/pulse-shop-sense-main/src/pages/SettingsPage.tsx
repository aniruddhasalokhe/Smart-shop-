import { Settings, Monitor, Users, Clock, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

export default function SettingsPage() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-muted-foreground">Configure shop floor parameters</p>
      </div>

      <Tabs defaultValue="machines" className="space-y-4">
        <TabsList className="bg-secondary">
          <TabsTrigger value="machines"><Monitor className="h-3.5 w-3.5 mr-1" /> Machines</TabsTrigger>
          <TabsTrigger value="operators"><Users className="h-3.5 w-3.5 mr-1" /> Operators</TabsTrigger>
          <TabsTrigger value="cycle"><Clock className="h-3.5 w-3.5 mr-1" /> Cycle Time</TabsTrigger>
          <TabsTrigger value="shifts"><Calendar className="h-3.5 w-3.5 mr-1" /> Shifts</TabsTrigger>
        </TabsList>

        <TabsContent value="machines" className="card-industrial space-y-4">
          <h3 className="font-semibold font-mono-display">Machine Setup</h3>
          <p className="text-sm text-muted-foreground">Add or edit machines on your shop floor.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Machine Name</Label>
              <Input placeholder="e.g., CNC Mill Alpha" />
            </div>
            <div className="space-y-2">
              <Label>Machine Type</Label>
              <Input placeholder="e.g., CNC Milling" />
            </div>
            <div className="space-y-2">
              <Label>Location</Label>
              <Input placeholder="e.g., Bay A" />
            </div>
          </div>
          <Button onClick={() => toast.success("Machine added successfully")}>Add Machine</Button>
        </TabsContent>

        <TabsContent value="operators" className="card-industrial space-y-4">
          <h3 className="font-semibold font-mono-display">Operator Setup</h3>
          <p className="text-sm text-muted-foreground">Add operators to the system.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Operator Name</Label>
              <Input placeholder="Full name" />
            </div>
            <div className="space-y-2">
              <Label>Employee ID</Label>
              <Input placeholder="e.g., OP-08" />
            </div>
            <div className="space-y-2">
              <Label>Shift</Label>
              <Input placeholder="e.g., Morning" />
            </div>
          </div>
          <Button onClick={() => toast.success("Operator added successfully")}>Add Operator</Button>
        </TabsContent>

        <TabsContent value="cycle" className="card-industrial space-y-4">
          <h3 className="font-semibold font-mono-display">Cycle Time Configuration</h3>
          <p className="text-sm text-muted-foreground">Set default cycle times per machine type.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>CNC Milling (seconds)</Label>
              <Input type="number" defaultValue="45" />
            </div>
            <div className="space-y-2">
              <Label>CNC Turning (seconds)</Label>
              <Input type="number" defaultValue="30" />
            </div>
            <div className="space-y-2">
              <Label>Surface Grinding (seconds)</Label>
              <Input type="number" defaultValue="20" />
            </div>
          </div>
          <Button onClick={() => toast.success("Cycle times updated")}>Save Configuration</Button>
        </TabsContent>

        <TabsContent value="shifts" className="card-industrial space-y-4">
          <h3 className="font-semibold font-mono-display">Shift Timing</h3>
          <p className="text-sm text-muted-foreground">Configure shift schedules.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Morning Shift</Label>
              <Input defaultValue="06:00 - 14:00" />
            </div>
            <div className="space-y-2">
              <Label>Afternoon Shift</Label>
              <Input defaultValue="14:00 - 22:00" />
            </div>
            <div className="space-y-2">
              <Label>Night Shift</Label>
              <Input defaultValue="22:00 - 06:00" />
            </div>
          </div>
          <Button onClick={() => toast.success("Shift timings saved")}>Save Shifts</Button>
        </TabsContent>
      </Tabs>

      {/* Future Features */}
      <div className="card-industrial border-dashed">
        <h3 className="font-semibold font-mono-display text-muted-foreground mb-2">Coming Soon</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {['IoT Machine Integration', 'Barcode Scanning', 'AI Productivity Prediction', 'OEE Tracking'].map(f => (
            <div key={f} className="p-3 rounded-md bg-secondary/30 text-center">
              <p className="text-xs text-muted-foreground">{f}</p>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
