import { BarChart3, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { productionData, weeklyData, machineUtilization, operators } from "@/data/mockData";
import { motion } from "framer-motion";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  LineChart, Line, PieChart, Pie, Cell
} from "recharts";
import { toast } from "sonner";

const COLORS = ['hsl(199 89% 48%)', 'hsl(142 71% 45%)', 'hsl(45 93% 47%)', 'hsl(280 65% 60%)', 'hsl(0 72% 51%)'];

const downtimeData = [
  { reason: 'Breakdown', hours: 4.5 },
  { reason: 'Tool Change', hours: 2.1 },
  { reason: 'Material Wait', hours: 1.8 },
  { reason: 'Maintenance', hours: 3.2 },
  { reason: 'Other', hours: 0.9 },
];

export default function Reports() {
  const chartTooltipStyle = { background: 'hsl(220 18% 13%)', border: '1px solid hsl(220 15% 20%)', borderRadius: 8, fontSize: 12 };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Production Reports</h1>
          <p className="text-sm text-muted-foreground">Analytics and performance insights</p>
        </div>
        <Button onClick={() => toast.info("Export feature coming soon")} variant="secondary">
          <Download className="h-4 w-4 mr-2" /> Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Daily Production */}
        <div className="card-industrial">
          <h3 className="text-sm font-semibold font-mono-display mb-4">Daily Production</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={productionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 20%)" />
                <XAxis dataKey="hour" tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <YAxis tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <Tooltip contentStyle={chartTooltipStyle} />
                <Bar dataKey="production" fill="hsl(199 89% 48%)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="target" fill="hsl(215 15% 35%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Machine Utilization */}
        <div className="card-industrial">
          <h3 className="text-sm font-semibold font-mono-display mb-4">Machine Utilization (%)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={machineUtilization} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 20%)" />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} width={60} />
                <Tooltip contentStyle={chartTooltipStyle} />
                <Bar dataKey="utilization" fill="hsl(142 71% 45%)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Operator Efficiency */}
        <div className="card-industrial">
          <h3 className="text-sm font-semibold font-mono-display mb-4">Operator Efficiency</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={operators.map(o => ({ name: o.name.split(' ')[0], efficiency: o.efficiency }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 20%)" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <Tooltip contentStyle={chartTooltipStyle} />
                <Bar dataKey="efficiency" fill="hsl(280 65% 60%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Downtime Analysis */}
        <div className="card-industrial">
          <h3 className="text-sm font-semibold font-mono-display mb-4">Downtime Analysis</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={downtimeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 20%)" />
                <XAxis dataKey="reason" tick={{ fontSize: 10, fill: 'hsl(215 15% 55%)' }} />
                <YAxis tick={{ fontSize: 11, fill: 'hsl(215 15% 55%)' }} />
                <Tooltip contentStyle={chartTooltipStyle} />
                <Bar dataKey="hours" fill="hsl(0 72% 51%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
