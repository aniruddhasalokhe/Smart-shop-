export type MachineStatus = 'running' | 'idle' | 'breakdown' | 'maintenance';
export type OperatorStatus = 'active' | 'break' | 'absent';
export type JobStatus = 'in-progress' | 'completed' | 'pending' | 'stopped';
export type IssueType = 'breakdown' | 'tool-failure' | 'material-issue' | 'quality-issue';
export type UserRole = 'admin' | 'supervisor' | 'operator';

export interface Machine {
  id: string;
  name: string;
  type: string;
  location: string;
  status: MachineStatus;
  operatorId: string | null;
  operatorName: string | null;
  currentJobId: string | null;
  currentJobName: string | null;
  cycleTime: number; // seconds
  partsCompleted: number;
  targetParts: number;
  uptime: number; // percentage
  lastMaintenance: string;
}

export interface Operator {
  id: string;
  name: string;
  machineAssigned: string | null;
  shift: string;
  attendanceStatus: OperatorStatus;
  checkInTime: string | null;
  efficiency: number;
  avatar: string;
}

export interface Job {
  id: string;
  partName: string;
  machineId: string;
  machineName: string;
  operatorId: string;
  operatorName: string;
  targetQuantity: number;
  producedQuantity: number;
  status: JobStatus;
  startTime: string;
  cycleTime: number;
}

export interface Issue {
  id: string;
  machineId: string;
  machineName: string;
  type: IssueType;
  description: string;
  reportedBy: string;
  reportedAt: string;
  status: 'open' | 'in-progress' | 'resolved';
}

export interface Notification {
  id: string;
  type: 'warning' | 'error' | 'info';
  message: string;
  timestamp: string;
  read: boolean;
}

export const machines: Machine[] = [
  { id: 'CNC-01', name: 'CNC Mill Alpha', type: 'CNC Milling', location: 'Bay A', status: 'running', operatorId: 'OP-01', operatorName: 'James Wilson', currentJobId: 'JOB-101', currentJobName: 'Shaft Bearing Housing', cycleTime: 45, partsCompleted: 128, targetParts: 200, uptime: 94.2, lastMaintenance: '2026-03-01' },
  { id: 'CNC-02', name: 'CNC Lathe Beta', type: 'CNC Turning', location: 'Bay A', status: 'idle', operatorId: null, operatorName: null, currentJobId: null, currentJobName: null, cycleTime: 0, partsCompleted: 0, targetParts: 0, uptime: 78.5, lastMaintenance: '2026-02-28' },
  { id: 'CNC-03', name: 'CNC Mill Gamma', type: 'CNC Milling', location: 'Bay B', status: 'running', operatorId: 'OP-03', operatorName: 'Sarah Chen', currentJobId: 'JOB-103', currentJobName: 'Gear Assembly', cycleTime: 32, partsCompleted: 85, targetParts: 150, uptime: 91.8, lastMaintenance: '2026-03-05' },
  { id: 'LTH-01', name: 'Lathe Delta', type: 'Manual Lathe', location: 'Bay B', status: 'breakdown', operatorId: 'OP-04', operatorName: 'Mike Torres', currentJobId: 'JOB-104', currentJobName: 'Piston Rod', cycleTime: 0, partsCompleted: 42, targetParts: 100, uptime: 45.2, lastMaintenance: '2026-02-15' },
  { id: 'GRN-01', name: 'Grinder Epsilon', type: 'Surface Grinder', location: 'Bay C', status: 'running', operatorId: 'OP-05', operatorName: 'Lisa Park', currentJobId: 'JOB-105', currentJobName: 'Valve Seat', cycleTime: 18, partsCompleted: 210, targetParts: 300, uptime: 88.7, lastMaintenance: '2026-03-08' },
  { id: 'DRL-01', name: 'Drill Press Zeta', type: 'Drill Press', location: 'Bay C', status: 'maintenance', operatorId: null, operatorName: null, currentJobId: null, currentJobName: null, cycleTime: 0, partsCompleted: 0, targetParts: 0, uptime: 62.3, lastMaintenance: '2026-03-10' },
  { id: 'CNC-04', name: 'CNC Router Eta', type: '5-Axis CNC', location: 'Bay A', status: 'running', operatorId: 'OP-02', operatorName: 'David Kim', currentJobId: 'JOB-106', currentJobName: 'Turbine Blade', cycleTime: 120, partsCompleted: 15, targetParts: 50, uptime: 96.1, lastMaintenance: '2026-03-09' },
  { id: 'WLD-01', name: 'Welder Theta', type: 'MIG Welder', location: 'Bay D', status: 'idle', operatorId: null, operatorName: null, currentJobId: null, currentJobName: null, cycleTime: 0, partsCompleted: 0, targetParts: 0, uptime: 71.4, lastMaintenance: '2026-03-02' },
];

export const operators: Operator[] = [
  { id: 'OP-01', name: 'James Wilson', machineAssigned: 'CNC-01', shift: 'Morning', attendanceStatus: 'active', checkInTime: '06:00', efficiency: 92.5, avatar: 'JW' },
  { id: 'OP-02', name: 'David Kim', machineAssigned: 'CNC-04', shift: 'Morning', attendanceStatus: 'active', checkInTime: '06:15', efficiency: 88.3, avatar: 'DK' },
  { id: 'OP-03', name: 'Sarah Chen', machineAssigned: 'CNC-03', shift: 'Morning', attendanceStatus: 'active', checkInTime: '05:55', efficiency: 95.1, avatar: 'SC' },
  { id: 'OP-04', name: 'Mike Torres', machineAssigned: 'LTH-01', shift: 'Morning', attendanceStatus: 'active', checkInTime: '06:30', efficiency: 76.8, avatar: 'MT' },
  { id: 'OP-05', name: 'Lisa Park', machineAssigned: 'GRN-01', shift: 'Afternoon', attendanceStatus: 'active', checkInTime: '14:00', efficiency: 91.2, avatar: 'LP' },
  { id: 'OP-06', name: 'Tom Baker', machineAssigned: null, shift: 'Morning', attendanceStatus: 'break', checkInTime: '06:00', efficiency: 84.6, avatar: 'TB' },
  { id: 'OP-07', name: 'Ana Rodriguez', machineAssigned: null, shift: 'Afternoon', attendanceStatus: 'absent', checkInTime: null, efficiency: 89.4, avatar: 'AR' },
];

export const jobs: Job[] = [
  { id: 'JOB-101', partName: 'Shaft Bearing Housing', machineId: 'CNC-01', machineName: 'CNC Mill Alpha', operatorId: 'OP-01', operatorName: 'James Wilson', targetQuantity: 200, producedQuantity: 128, status: 'in-progress', startTime: '06:30', cycleTime: 45 },
  { id: 'JOB-102', partName: 'Flange Adapter', machineId: 'CNC-02', machineName: 'CNC Lathe Beta', operatorId: 'OP-06', operatorName: 'Tom Baker', targetQuantity: 100, producedQuantity: 100, status: 'completed', startTime: '06:00', cycleTime: 28 },
  { id: 'JOB-103', partName: 'Gear Assembly', machineId: 'CNC-03', machineName: 'CNC Mill Gamma', operatorId: 'OP-03', operatorName: 'Sarah Chen', targetQuantity: 150, producedQuantity: 85, status: 'in-progress', startTime: '06:15', cycleTime: 32 },
  { id: 'JOB-104', partName: 'Piston Rod', machineId: 'LTH-01', machineName: 'Lathe Delta', operatorId: 'OP-04', operatorName: 'Mike Torres', targetQuantity: 100, producedQuantity: 42, status: 'stopped', startTime: '07:00', cycleTime: 55 },
  { id: 'JOB-105', partName: 'Valve Seat', machineId: 'GRN-01', machineName: 'Grinder Epsilon', operatorId: 'OP-05', operatorName: 'Lisa Park', targetQuantity: 300, producedQuantity: 210, status: 'in-progress', startTime: '14:00', cycleTime: 18 },
  { id: 'JOB-106', partName: 'Turbine Blade', machineId: 'CNC-04', machineName: 'CNC Router Eta', operatorId: 'OP-02', operatorName: 'David Kim', targetQuantity: 50, producedQuantity: 15, status: 'in-progress', startTime: '06:45', cycleTime: 120 },
  { id: 'JOB-107', partName: 'Bracket Mount', machineId: 'WLD-01', machineName: 'Welder Theta', operatorId: 'OP-06', operatorName: 'Tom Baker', targetQuantity: 80, producedQuantity: 0, status: 'pending', startTime: '', cycleTime: 15 },
];

export const issues: Issue[] = [
  { id: 'ISS-01', machineId: 'LTH-01', machineName: 'Lathe Delta', type: 'breakdown', description: 'Spindle motor overheating, unusual vibration detected', reportedBy: 'Mike Torres', reportedAt: '2026-03-12 09:15', status: 'open' },
  { id: 'ISS-02', machineId: 'DRL-01', machineName: 'Drill Press Zeta', type: 'tool-failure', description: 'Drill bit snapped, scheduled for replacement', reportedBy: 'Tom Baker', reportedAt: '2026-03-12 08:30', status: 'in-progress' },
];

export const notifications: Notification[] = [
  { id: 'N-01', type: 'error', message: 'Machine LTH-01 breakdown reported – Spindle motor overheating', timestamp: '09:15', read: false },
  { id: 'N-02', type: 'warning', message: 'Machine CNC-02 has been idle for 15 minutes', timestamp: '08:45', read: false },
  { id: 'N-03', type: 'warning', message: 'Production on JOB-104 is below target (42%)', timestamp: '08:30', read: true },
  { id: 'N-04', type: 'info', message: 'Operator Ana Rodriguez marked absent for today', timestamp: '07:00', read: true },
  { id: 'N-05', type: 'info', message: 'Drill Press Zeta scheduled maintenance completed', timestamp: '06:00', read: true },
];

export const productionData = [
  { hour: '06:00', production: 45, target: 50 },
  { hour: '07:00', production: 62, target: 50 },
  { hour: '08:00', production: 55, target: 50 },
  { hour: '09:00', production: 38, target: 50 },
  { hour: '10:00', production: 58, target: 50 },
  { hour: '11:00', production: 42, target: 50 },
  { hour: '12:00', production: 30, target: 50 },
  { hour: '13:00', production: 48, target: 50 },
  { hour: '14:00', production: 52, target: 50 },
  { hour: '15:00', production: 50, target: 50 },
];

export const weeklyData = [
  { day: 'Mon', production: 420, efficiency: 88 },
  { day: 'Tue', production: 380, efficiency: 82 },
  { day: 'Wed', production: 450, efficiency: 91 },
  { day: 'Thu', production: 410, efficiency: 86 },
  { day: 'Fri', production: 390, efficiency: 84 },
];

export const machineUtilization = [
  { name: 'CNC-01', utilization: 94 },
  { name: 'CNC-02', utilization: 78 },
  { name: 'CNC-03', utilization: 92 },
  { name: 'LTH-01', utilization: 45 },
  { name: 'GRN-01', utilization: 89 },
  { name: 'DRL-01', utilization: 62 },
  { name: 'CNC-04', utilization: 96 },
  { name: 'WLD-01', utilization: 71 },
];
